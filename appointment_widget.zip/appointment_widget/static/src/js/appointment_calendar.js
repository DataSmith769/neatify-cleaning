odoo.define('appointment_widget.calendar', function (require) {
    "use strict";
    const publicWidget = require('web.public.widget');

    publicWidget.registry.AppointmentCalendar = publicWidget.Widget.extend({
        selector: '.appointment-section',
        start: function () {
            const calendarDays = this.el.querySelectorAll('.appointment-day');
            const timeSelect = this.el.querySelector('#appointment_time');
            const today = new Date();
            const todayDate = today.getDate();
            let selectedDay = null;

            calendarDays.forEach(day => {
                const dayNumber = parseInt(day.textContent.trim());
                if (dayNumber === todayDate) {
                    day.classList.add('today-highlight');
                }

                day.style.cursor = 'pointer';
                day.addEventListener('click', function () {
                    if (selectedDay) selectedDay.classList.remove('selected-day');
                    this.classList.remove('today-highlight');
                    this.classList.add('selected-day');
                    selectedDay = this;
                    document.querySelector('#selected_appointment_date').value = this.textContent.trim();
                });
            });

            if (timeSelect) {
                timeSelect.addEventListener('change', function () {
                    document.querySelector('#selected_appointment_time').value = this.value;
                });
            }
        }
    });
});
