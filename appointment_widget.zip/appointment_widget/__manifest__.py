{
    "name": "Appointment Calendar Widget",
    "version": "1.0",
    "summary": "Custom visual calendar selector for website appointments",
    "author": "Kenneth E. Smith",
    "category": "Website",
    "depends": ["website"],
    "data": [
        "views/assets.xml",
        "views/calendar_template.xml"
    ],
    "installable": True,
    "application": False
}
