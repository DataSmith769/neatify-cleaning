{
    "name": "Cart Price Selector Enhancer",
    "version": "1.0",
    "category": "Website",
    "summary": "Dynamically updates cart pricing based on selected square footage.",
    "author": "Kenneth E. Smith",
    "depends": ["website_sale"],
    "data": ["views/assets.xml"],
    "installable": True,
    "application": False,
    "auto_install": False
}
