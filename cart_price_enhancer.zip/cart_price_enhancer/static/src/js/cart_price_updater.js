odoo.define('cart_price_enhancer.cart_price_updater', function (require) {
    'use strict';

    const publicWidget = require('web.public.widget');

    publicWidget.registry.CartPriceUpdater = publicWidget.Widget.extend({
        selector: '#shop_cart',
        events: {
            'change #service_range_select': '_updatePrices',
            'change .css_quantity input': '_updatePrices',
        },

        _updatePrices: function () {
            const select = document.getElementById('service_range_select');
            const qtyInput = document.querySelector('.css_quantity input');
            if (!select || !qtyInput) return;

            const selectedOption = select.options[select.selectedIndex];
            const unitPrice = parseFloat(selectedOption.getAttribute('data-price') || 0);
            const quantity = parseInt(qtyInput.value || "1");
            const subtotalAmount = unitPrice * quantity;

            // Update unit price
            const unitPriceDisplay = document.querySelector('#cart_products .oe_currency_value');
            if (unitPriceDisplay) {
                unitPriceDisplay.textContent = unitPrice.toFixed(2);
            }

            // Update subtotal and total using actual DOM structure
            const subtotal = document.querySelector('#order_total_untaxed .oe_currency_value');
            const tax = document.querySelector('#order_total_taxes .oe_currency_value');
            const total = document.querySelector('#order_total .oe_currency_value');

            if (subtotal && total) {
                const taxValue = tax ? parseFloat(tax.textContent) || 0 : 0;
                subtotal.textContent = subtotalAmount.toFixed(2);
                total.textContent = (subtotalAmount + taxValue).toFixed(2);
            }

            console.log(`✔ Updated: $${unitPrice} × ${quantity} → Subtotal $${subtotalAmount}`);
        },
    });

    return publicWidget.registry.CartPriceUpdater;
});
